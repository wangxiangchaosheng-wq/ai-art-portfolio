import { Artwork } from '@/types/artwork';

// 后端API基础URL - 在实际部署时替换为您的后端服务器地址
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

// 获取所有作品
export const fetchArtworks = async (): Promise<Artwork[]> => {
  try {
    // 尝试从后端API获取数据
    const response = await fetch(`${API_BASE_URL}/artworks`);
    
    if (response.ok) {
      return await response.json();
    }
    
    // API请求失败时使用模拟数据
    console.warn('Failed to fetch from API, using mock data');
    return getMockArtworks();
  } catch (error) {
    console.error('Error fetching artworks:', error);
    return getMockArtworks();
  }
};

// 获取单个作品详情
export const fetchArtworkById = async (id: string): Promise<Artwork | null> => {
  try {
    const response = await fetch(`${API_BASE_URL}/artworks/${id}`);
    
    if (response.ok) {
      return await response.json();
    }
    
    // API请求失败时从模拟数据中查找
    const artworks = getMockArtworks();
    return artworks.find(artwork => artwork.id === id) || null;
  } catch (error) {
    console.info('Using mock data for artwork:', id);
    const artworks = getMockArtworks();
    return artworks.find(artwork => artwork.id === id) || null;
  }
}

// 上传新作品
export const uploadArtwork = async (artworkData: FormData): Promise<Artwork | null> => {
  try {
    // 获取认证令牌
    const token = localStorage.getItem('auth_token');
    
    const response = await fetch(`${API_BASE_URL}/artworks`, {
      method: 'POST',
      body: artworkData,
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (response.ok) {
      return await response.json();
    }
    
    console.error('Failed to upload artwork to API');
    return null;
  } catch (error) {
    console.error('Error uploading artwork:', error);
    return null;
  }
};

// 模拟数据 - 仅在API不可用时使用
export const getMockArtworks = (): Artwork[] => {
  return [
    {
      id: '7',
      title: 'Hundred Flavors Little Ghosts',
      description: 'Surreal photorealistic portrait of seven whimsical "Hundred Flavors Little Ghosts" in a massive absurd feast, each ghost surrounded by mountains of hyper-detailed food that matches their taste personality. Style inspired by hyper-realistic absurdist photography, harsh midday sunlight, clear sky backdrop, cinematic color grading, slightly desaturated tones, subtle film grain. Sour — pale lime-green skin, small twisted horns, sitting in a pile of citrus fruits and pickles, holding a glass of lemon soda; Sweet — plump figure in cotton candy-textured suit, surrounded by cakes and candy, holding a huge lollipop; Spicy — flame-red outfit with heat shimmer effect, sitting in a pile of chili peppers, holding skewers; Bitter — dark green wool coat, sitting among piles of cocoa beans and black coffee bags, sipping from a porcelain cup; Salty — sea-blue robe, surrounded by pretzels, chips, and salted fish, sprinkling coarse salt; Umami — brown-green silk robe, surrounded by sushi, broth bowls, and seaweed, holding chopsticks; Astringent — deep purple textured skin, surrounded by grapes, tea leaves, and persimmons, weaving a vine crown. Highly detailed textures: realistic skin pores, food grease and crumbs, fabric fibers, plastic packaging reflections. Wide composition with all seven characters, each in their own food mound, arranged like a surreal group portrait.',
      imageUrl: 'https://lf-code-agent.coze.cn/obj/x-ai-cn/251721486594/attachment/image_20250815144102.png',
      creator: 'AI Artist',
      createdAt: '2025-08-15',
      tags: ['surreal', 'photorealistic', 'portrait', 'food', 'ghosts', 'whimsical', 'absurd', 'feast'],
      styles: ['surrealism', 'hyperrealism', 'portrait', 'absurd photography'],
      copyright: 'cc-by',
      likes: 0,
      views: 0
    },
    {
      id: '1',
      title: 'Neon Dreams',
      description: 'A vibrant cityscape with neon lights reflecting on wet streets, cyberpunk aesthetic with futuristic buildings',
      imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=cyberpunk%20cityscape%20neon%20lights%20futuristic%20buildings&sign=756f16f602fa6b40ed28c4cf3fd3266d',
      creator: 'AI Artist',
      createdAt: '2025-07-15',
      tags: ['cyberpunk', 'city', 'neon', 'futuristic'],
      styles: ['digital art', 'cyberpunk', 'concept art'],
      copyright: 'cc-by',
      likes: 245,
      views: 1320
    },
    {
      id: '2',
      title: 'Ethereal Landscapes',
      description: 'Surreal mountain landscape with floating islands and crystal lakes, dreamlike atmosphere with soft lighting',
      imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=surreal%20landscape%20floating%20islands%20crystal%20lakes%20dreamlike&sign=b86e1d7fceb700eb19bf00e5e88438da',
      creator: 'AI Artist',
      createdAt: '2025-07-20',
      tags: ['landscape', 'surreal', 'dream', 'mountains'],
      styles: ['surrealism', 'landscape', 'digital painting'],
      copyright: 'cc-by-nc',
      likes: 189,
      views: 956
    },
    {
      id: '3',
      title: 'Abstract Emotions',
      description: 'Abstract representation of human emotions through color and form, dynamic composition with flowing shapes',
      imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=abstract%20painting%20human%20emotions%20colorful%20dynamic%20composition&sign=d801e172d217c4587010698b2c1afe48',
      creator: 'AI Artist',
      createdAt: '2025-07-25',
      tags: ['abstract', 'emotions', 'color', 'expression'],
      styles: ['abstract', 'expressionism', 'modern art'],
      copyright: 'all-rights-reserved',
      likes: 312,
      views: 1780
    },
    {
      id: '4',
      title: 'Ancient Futures',
      description: 'Blend of ancient architecture with futuristic technology, harmonious fusion of past and future',
      imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=ancient%20architecture%20futuristic%20technology%20fusion%20past%20and%20future&sign=929f54449e4bbee2ce27582d061e0cf3',
      creator: 'AI Artist',
      createdAt: '2025-08-02',
      tags: ['architecture', 'futuristic', 'ancient', 'fusion'],
      styles: ['concept art', 'futurism', 'architectural visualization'],
      copyright: 'cc-by-sa',
      likes: 156,
      views: 890
    },
    {
      id: '5',
      title: 'Biomechanical Wonders',
      description: 'Intricate biomechanical creatures with organic and mechanical elements in perfect harmony',
      imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=biomechanical%20creature%20organic%20mechanical%20elements%20intricate%20design&sign=93f852d6f3646c4e716aa1504318bf9f',
      creator: 'AI Artist',
      createdAt: '2025-08-08',
      tags: ['creature', 'biomechanical', 'organic', 'mechanical'],
      styles: ['concept art', 'sci-fi', 'illustration'],
      copyright: 'cc-by',
      likes: 289,
      views: 2105
    },
    {
      id: '6',
      title: 'Cosmic Journey',
      description: 'Vibrant space scene with nebulas, galaxies and distant planets, cosmic exploration theme',
      imageUrl: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=cosmic%20journey%20nebulas%20galaxies%20planets%20vibrant%20colors&sign=718e02e911537907cf7db318dab575b0',
      creator: 'AI Artist',
      createdAt: '2025-08-12',
      tags: ['space', 'cosmic', 'nebula', 'galaxy'],
      styles: ['space art', 'digital art', 'sci-fi'],
      copyright: 'cc-by-nc-sa',
      likes: 342,
      views: 2750
    }
  ];
};

// 所有艺术风格列表
export const allArtStyles = [
  'digital art', 
  'cyberpunk', 
  'concept art', 
  'surrealism', 
  'hyperrealism',
  'landscape', 
  'digital painting',
  'abstract', 
  'expressionism', 
  'modern art', 
  'futurism', 
  'architectural visualization',
  'sci-fi', 
  'illustration', 
  'space art',
  'absurd photography',
  'portrait'
].sort();

// 添加新作品到模拟数据
export const addArtwork = (artwork: Omit<Artwork, 'id' | 'creator' | 'createdAt' | 'likes' | 'views'>) => {
  const today = new Date().toISOString().split('T')[0];
  const allArtworks = getMockArtworks();
  const newId = (allArtworks.length + 1).toString();
  
  // 为新上传的作品生成图片URL
  const encodedTitle = encodeURIComponent(artwork.title || '');
  const imageUrl = artwork.imageUrl || `https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=${encodedTitle}%20${artwork.styles[0] || 'art'}`;
  
  const newArtwork: Artwork = {
    id: newId,
    creator: 'Current User',
    createdAt: today,
    likes: 0,
    views: 0,
    imageUrl,
    ...artwork
  };
  
  // 将新作品添加到本地存储
  const storedArtworks = JSON.parse(localStorage.getItem('userArtworks') || '[]');
  storedArtworks.unshift(newArtwork);
  localStorage.setItem('userArtworks', JSON.stringify(storedArtworks));
  
  return newArtwork;
};