import { Routes, Route } from "react-router-dom";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Upload from "@/pages/Upload";
import Detail from "@/pages/Detail";
import Search from "@/pages/Search";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState({ name: "Guest", avatar: "" });

  const login = (username: string) => {
    setIsAuthenticated(true);
    setUser({ name: username, avatar: `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=user%20avatar%20${username}` });
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser({ name: "Guest", avatar: "" });
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, user, login, logout }}
    >
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
        <Navbar />
        <main className="flex-grow container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/upload" element={<Upload />} />
            <Route path="/artwork/:id" element={<Detail />} />
            <Route path="/search" element={<Search />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </AuthContext.Provider>
  );
}
