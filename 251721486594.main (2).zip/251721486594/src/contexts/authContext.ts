import { createContext } from "react";

interface User {
  name: string;
  avatar: string;
}

interface AuthContextType {
  isAuthenticated: boolean;
  user: User;
  login: (username: string) => void;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  user: { name: "Guest", avatar: "" },
  login: () => {},
  logout: () => {},
});