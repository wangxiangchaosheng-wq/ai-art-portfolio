import { useSearchParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import ArtworkGrid from '@/components/ArtworkGrid';
import SearchBar from '@/components/SearchBar';
import FilterPanel from '@/components/FilterPanel';
import { getMockArtworks } from '@/mocks/artworks';
import { Artwork } from '@/types/artwork';

export default function Search() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialQuery = searchParams.get('query') || '';
  
  const [artworks, setArtworks] = useState<Artwork[]>([]);
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  
  // Load all artworks on component mount
  useEffect(() => {
    const loadArtworks = async () => {
      const data = await getMockArtworks();
      setArtworks(data);
    };
    
    loadArtworks();
  }, []);

  useEffect(() => {
    // Initial search with query from URL params
    handleSearch(initialQuery);
  }, [initialQuery]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    
    // Filter artworks based on query and active filters
    let filtered = [...artworks];
    
    // Text search filter
    if (query) {
      filtered = filtered.filter(artwork => 
        artwork.title.toLowerCase().includes(query.toLowerCase()) ||
        artwork.description.toLowerCase().includes(query.toLowerCase()) ||
        artwork.tags.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
      );
    }
    
    // Style filter
    if (activeFilters.length > 0) {
      filtered = filtered.filter(artwork => 
        activeFilters.some(filter => artwork.styles.includes(filter))
      );
    }
    
    setArtworks(filtered);
  };

  const handleFilter = (filters: string[]) => {
    setActiveFilters(filters);
    
    // Re-apply search with new filters
    handleSearch(searchQuery);
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center">
        <button
          onClick={() => navigate('/')}
          className="mr-4 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
        >
          <i className="fa-solid fa-arrow-left"></i>
        </button>
        <h1 className="text-2xl font-bold text-gray-800 dark:text-white">Search Results</h1>
      </div>
      
      <SearchBar onSearch={handleSearch} />
      
      <FilterPanel activeFilters={activeFilters} onFilterChange={handleFilter} />
      
      {artworks.length > 0 ? (
        <>
          <p className="text-gray-600 dark:text-gray-400">
            Showing {artworks.length} result{artworks.length !== 1 ? 's' : ''} for "{searchQuery}"
            {activeFilters.length > 0 && ` with ${activeFilters.length} filter${activeFilters.length !== 1 ? 's' : ''}`}
          </p>
          
          <ArtworkGrid artworks={artworks} />
        </>
      ) : (
        <div className="text-center py-16 bg-white dark:bg-gray-800 rounded-xl">
          <i className="fa-solid fa-search text-5xl text-gray-300 dark:text-gray-600 mb-4"></i>
          <h3 className="text-xl font-medium text-gray-800 dark:text-white mb-2">No results found</h3>
          <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
            We couldn't find any artworks matching your search criteria. Try adjusting your search terms or filters.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveFilters([]);
              handleSearch('');
            }}
            className="mt-6 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 font-medium"
          >
            Clear all filters and search
          </button>
        </div>
      )}
    </div>
  );}