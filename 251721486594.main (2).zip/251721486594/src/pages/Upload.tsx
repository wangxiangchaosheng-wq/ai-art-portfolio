import { useContext, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { AuthContext } from '@/contexts/authContext';
import { Artwork } from '@/types/artwork';
import { allArtStyles, uploadArtwork } from '@/mocks/artworks';

export default function Upload() {
  const { isAuthenticated } = useContext(AuthContext);
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Form state
  const [formData, setFormData] = useState<Partial<Artwork>>({
    title: '',
    description: '',
    tags: [],
    styles: [],
    copyright: 'cc-by' as Artwork['copyright']
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [tagInput, setTagInput] = useState('');

  // Redirect if not authenticated
  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      
      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTagAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()]
      }));
      setTagInput('');
    }
  };

  const handleTagRemove = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags?.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleStyleToggle = (style: string) => {
    setFormData(prev => {
      const currentStyles = prev.styles || [];
      if (currentStyles.includes(style)) {
        return {
          ...prev,
          styles: currentStyles.filter(s => s !== style)
        };
      } else {
        return {
          ...prev,
          styles: [...currentStyles, style]
        };
      }
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.title?.trim()) {
      toast.error('Please enter a title for your artwork');
      return;
    }
    
    if (!selectedFile) {
      toast.error('Please select an image file');
      return;
    }
    
    if (!formData.styles?.length) {
      toast.error('Please select at least one art style');
      return;
    }

    setIsLoading(true);
    
    try {
      // Create FormData for file upload
      const artworkData = new FormData();
      artworkData.append('title', formData.title);
      artworkData.append('description', formData.description || '');
      artworkData.append('tags', JSON.stringify(formData.tags || []));
      artworkData.append('styles', JSON.stringify(formData.styles || []));
      artworkData.append('copyright', formData.copyright || 'cc-by');
      artworkData.append('image', selectedFile);
      
      // Upload to API
      const newArtwork = await uploadArtwork(artworkData);
      
      if (newArtwork) {
        toast.success('Artwork uploaded successfully!');
        setTimeout(() => {
          navigate('/');
          setIsLoading(false);
        }, 2000);
      }
    } catch (error) {
      toast.error('Failed to upload artwork. Please try again.');
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-6">Upload New Artwork</h1>
      
      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Image Upload Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Artwork Image</h2>
          
          <div 
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              selectedFile 
                ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                : 'border-gray-300 dark:border-gray-600 hover:border-blue-500 dark:hover:border-blue-400'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />
            
            {previewUrl ? (
              <div className="relative mx-auto max-w-md">
                <img 
                  src={previewUrl} 
                  alt="Preview" 
                  className="max-w-full max-h-64 object-contain rounded-lg mx-auto"
                />
                <button
                  type="button"
                  onClick={() => {
                    setPreviewUrl(null);
                    setSelectedFile(null);
                  }}
                  className="absolute top-2 right-2 bg-white dark:bg-gray-800 rounded-full p-1 shadow-md text-gray-500 hover:text-red-500"
                >
                  <i className="fa-solid fa-times"></i>
                </button>
              </div>
            ) : (
              <>
                <i className="fa-solid fa-cloud-upload text-4xl text-gray-400 mb-3"></i>
                <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-1">Drag & Drop your image here</h3>
                <p className="text-gray-500 dark:text-gray-400 mb-4">or click to browse from your device</p>
                <p className="text-xs text-gray-400 dark:text-gray-500">
                  Supports JPG, PNG, WEBP up to 10MB
                </p>
              </>
            )}
          </div>
        </div>
        
        {/* Artwork Details Section */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Artwork Details</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Title *
              </label>
              <input
                type="text"
                id="title"
                value={formData.title || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                placeholder="Give your artwork a title"
                required
              />
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Description
              </label>
              <textarea
                id="description"
                value={formData.description || ''}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white min-h-[120px]"
                placeholder="Describe your artwork (inspiration, techniques, etc.)"
              ></textarea>
            </div>
            
            {/* Tags Section */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Tags
              </label>
              <div className="flex flex-col sm:flex-row gap-3">
                <form onSubmit={handleTagAdd} className="flex-grow">
                  <div className="relative">
                    <input
                      type="text"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleTagAdd(e)}
                      className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:text-white"
                      placeholder="Add tags (press Enter to add)"
                    />
                    <button
                      type="submit"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-blue-600 hover:bg-blue-700 text-white p-1 rounded"
                    >
                      <i className="fa-solid fa-plus"></i>
                    </button>
                  </div>
                </form>
              </div>
              
              {formData.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {formData.tags.map((tag) => (
                    <span 
                      key={tag} 
                      className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300"
                    >
                      {tag}
                      <button 
                        type="button" 
                        onClick={() => handleTagRemove(tag)}
                        className="ml-1 text-gray-500 hover:text-gray-700 dark:hover:text-gray-200"
                      >
                        <i className="fa-solid fa-times-circle"></i>
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
            
            {/* Art Styles Section */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Art Styles *
              </label>
              <div className="flex flex-wrap gap-2">
                {allArtStyles.map((style) => (
                  <button
                    key={style}
                    type="button"
                    onClick={() => handleStyleToggle(style)}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      formData.styles?.includes(style)
                        ? 'bg-blue-600 text-white hover:bg-blue-700'
                        : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                    }`}
                  >
                    {style}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Copyright Section */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                Copyright License *
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  { value: 'all-rights-reserved', label: 'All Rights Reserved' },
                  { value: 'cc-by', label: 'CC BY (Attribution)' },
                  { value: 'cc-by-sa', label: 'CC BY-SA (Attribution-ShareAlike)' },
                  { value: 'cc-by-nd', label: 'CC BY-ND (Attribution-NoDerivatives)' },
                  { value: 'cc-by-nc', label: 'CC BY-NC (Attribution-NonCommercial)' },
                  { value: 'cc-by-nc-sa', label: 'CC BY-NC-SA' },
                  { value: 'cc-by-nc-nd', label: 'CC BY-NC-ND' },
                ].map((option) => (
                  <label 
                    key={option.value}
                    className={`flex items-center p-3 border rounded-lg cursor-pointer transition-colors ${
                      formData.copyright === option.value
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20'
                        : 'border-gray-300 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="copyright"
                      value={option.value}
                      checked={formData.copyright === option.value}
                      onChange={(e) => setFormData(prev => ({ ...prev, copyright: e.target.value as Artwork['copyright'] }))}
                      className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                    />
                    <span className="ml-3 text-gray-700 dark:text-gray-300">{option.label}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="button"
            onClick={() => navigate('/')}
            className="mr-3 px-6 py-3 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            Cancel
          </button>
          
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors disabled:opacity-70 disabled:cursor-not-allowed flex items-center"
          >
            {isLoading ? (
              <>
                <i className="fa-solid fa-spinner fa-spin mr-2"></i>
                Uploading...
              </>
            ) : (
              <>
                <i className="fa-solid fa-upload mr-2"></i>
                Upload Artwork
              </>
            )}
          </button>
        </div>
      </form>
    </motion.div>
  );
}