import { useState, useEffect } from 'react';
import ArtworkGrid from '@/components/ArtworkGrid';
import SearchBar from '@/components/SearchBar';
import FilterPanel from '@/components/FilterPanel';
import { fetchArtworks, allArtStyles } from '@/mocks/artworks';
import { Artwork } from '@/types/artwork';
import { useLocation } from 'react-router-dom';
import { toast } from 'sonner';

export default function Home() {
  const [artworks, setArtworks] = useState<Artwork[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const location = useLocation();

  // 加载作品数据
  const loadArtworks = async () => {
    try {
      setLoading(true);
      const data = await fetchArtworks();
      setArtworks(data);
    } catch (error) {
      toast.error('Failed to load artworks');
      console.error('Error loading artworks:', error);
    } finally {
      setLoading(false);
    }
  };

  // 当页面加载或从其他页面导航回来时重新加载作品数据
  useEffect(() => {
    loadArtworks();
  }, [location]);

  // 应用搜索和筛选
  useEffect(() => {
    let filtered = [...artworks];
    
    // 应用搜索筛选
    if (searchQuery) {
      filtered = filtered.filter(artwork => 
        artwork.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        artwork.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        artwork.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }
    
    // 应用风格筛选
    if (activeFilters.length > 0) {
      filtered = filtered.filter(artwork => 
        activeFilters.some(filter => artwork.styles.includes(filter))
      );
    }
    
    setArtworks(filtered);
  }, [searchQuery, activeFilters]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleFilter = async (filters: string[]) => {
    setActiveFilters(filters);
    // In a real app, this would filter from API
    if (filters.length === 0) {
      // 如果没有筛选条件，检查是否有搜索查询
      if (searchQuery) {
        handleSearch(searchQuery);
      } else {
        loadArtworks();
      }
      return;
    }
    
    const allArtworks = await fetchArtworks();
    const filtered = allArtworks.filter(artwork => 
      filters.some(filter => artwork.styles.includes(filter))
    );
    setArtworks(filtered);
  };

  return (
    <div className="space-y-8">
      <section className="text-center max-w-3xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          AI Art Portfolio
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
          Explore a collection of AI-generated artworks with advanced search and filtering capabilities
        </p>
        <SearchBar onSearch={handleSearch} />
      </section>

      <FilterPanel activeFilters={activeFilters} onFilterChange={handleFilter} />
      
      <ArtworkGrid artworks={artworks} />
      
      {artworks.length === 0 && (
        <div className="text-center py-16">
          <h3 className="text-xl font-medium text-gray-500 dark:text-gray-400">No artworks found</h3>
          <p className="mt-2 text-gray-400 dark:text-gray-500">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}