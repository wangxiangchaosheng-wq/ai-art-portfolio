import { useContext, useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import { fetchArtworkById } from '@/mocks/artworks';
import { Artwork, getCopyrightDescription, getCopyrightLabel } from '@/types/artwork';
import { AuthContext } from '@/contexts/authContext';
import CopyrightBadge from '@/components/CopyrightBadge';

export default function Detail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useContext(AuthContext);
  const [isLiked, setIsLiked] = useState(false);
  
  // Find the artwork with the matching ID
  const [artwork, setArtwork] = useState<Artwork | null>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadArtwork = async () => {
      try {
        setLoading(true);
        const data = await fetchArtworkById(id!);
        setArtwork(data);
        
        if (!data) {
          navigate('/');
          toast.error('Artwork not found');
        }
      } catch (error) {
        toast.error('Failed to load artwork details');
        console.error('Error loading artwork:', error);
        navigate('/');
      } finally {
        setLoading(false);
      }
    };
    
    if (id) {
      loadArtwork();
    }
  }, [id, navigate]);
  
  // If loading or artwork not found, show loading state
  if (loading || !artwork) {
    return (
      <div className="flex items-center justify-center min-h-[500px]">
        <div className="text-center">
          <i className="fa-solid fa-circle-notch fa-spin text-4xl text-blue-600 mb-4"></i>
          <p className="text-lg text-gray-600 dark:text-gray-400">Loading artwork details...</p>
        </div>
      </div>
    );
  }

  const handleLikeToggle = () => {
    if (!isAuthenticated) {
      toast.info('Please login to like artworks');
      return;
    }
    setIsLiked(!isLiked);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <button
        onClick={() => navigate('/')}
        className="inline-flex items-center text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 mb-6"
      >
        <i className="fa-solid fa-arrow-left mr-2"></i>
        Back to gallery
      </button>
      
      <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm overflow-hidden">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Artwork Image */}
          <div className="relative bg-gray-100 dark:bg-gray-900 p-4 lg:p-8 flex items-center justify-center">
            <img
              src={artwork.imageUrl}
              alt={artwork.title}
              className="max-w-full max-h-[60vh] object-contain rounded-lg shadow-md"
            />
          </div>
          
          {/* Artwork Details */}
          <div className="p-6 lg:p-8">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h1 className="text-3xl font-bold text-gray-800 dark:text-white">{artwork.title}</h1>
                <p className="text-gray-600 dark:text-gray-400">by {artwork.creator}</p>
              </div>
              <CopyrightBadge type={artwork.copyright} />
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-2">Description</h2>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{artwork.description}</p>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-3">Details</h2>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block">Created</span>
                  <span className="text-gray-800 dark:text-white font-medium">{artwork.createdAt}</span>
                </div>
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block">Views</span>
                  <span className="text-gray-800 dark:text-white font-medium">{artwork.views}</span>
                </div>
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block">License</span>
                  <span className="text-gray-800 dark:text-white font-medium">{getCopyrightLabel(artwork.copyright)}</span>
                </div>
                <div>
                  <span className="text-gray-500 dark:text-gray-400 block">License Details</span>
                  <span className="text-gray-800 dark:text-white font-medium text-xs">{getCopyrightDescription(artwork.copyright)}</span>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-3">Styles & Tags</h2>
              <div className="flex flex-wrap gap-2">
                {artwork.styles.map((style) => (
                  <span key={style} className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 rounded-full text-sm font-medium">
                    {style}
                  </span>
                ))}
                {artwork.tags.map((tag) => (
                  <span key={tag} className="px-3 py-1 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full text-sm">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="mt-8 flex items-center justify-between">
              <button
                onClick={handleLikeToggle}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  isAuthenticated
                    ? isLiked
                      ? 'bg-red-500 hover:bg-red-600 text-white'
                      : 'bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-800 dark:text-gray-200'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                }`}
                disabled={!isAuthenticated}
              >
                <i className={`fa-solid fa-heart ${isLiked ? 'fill-current' : ''}`}></i>
                <span>{isLiked ? 'Liked' : 'Like'}</span>
                <span className="ml-1 text-gray-600 dark:text-gray-300">({artwork.likes})</span>
              </button>
              
              <div className="flex space-x-3">
                <button className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 transition-colors">
                  <i className="fa-solid fa-share-alt" aria-label="Share artwork"></i>
                </button>
                <button className="p-2 rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-300 transition-colors">
                  <i className="fa-solid fa-download" aria-label="Download artwork"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}