export interface Artwork {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  creator: string;
  createdAt: string;
  tags: string[];
  styles: string[];
  copyright: 'all-rights-reserved' | 'cc-by' | 'cc-by-sa' | 'cc-by-nd' | 'cc-by-nc' | 'cc-by-nc-sa' | 'cc-by-nc-nd';
  likes: number;
  views: number;
}

export const getCopyrightLabel = (type: Artwork['copyright']): string => {
  switch (type) {
    case 'all-rights-reserved':
      return 'All Rights Reserved';
    case 'cc-by':
      return 'CC BY';
    case 'cc-by-sa':
      return 'CC BY-SA';
    case 'cc-by-nd':
      return 'CC BY-ND';
    case 'cc-by-nc':
      return 'CC BY-NC';
    case 'cc-by-nc-sa':
      return 'CC BY-NC-SA';
    case 'cc-by-nc-nd':
      return 'CC BY-NC-ND';
    default:
      return 'Unknown License';
  }
};

export const getCopyrightDescription = (type: Artwork['copyright']): string => {
  switch (type) {
    case 'all-rights-reserved':
      return 'All rights reserved. No reuse without permission.';
    case 'cc-by':
      return 'Attribution. You must give appropriate credit.';
    case 'cc-by-sa':
      return 'Attribution-ShareAlike. Share under the same license.';
    case 'cc-by-nd':
      return 'Attribution-NoDerivatives. No modifications allowed.';
    case 'cc-by-nc':
      return 'Attribution-NonCommercial. Non-commercial use only.';
    case 'cc-by-nc-sa':
      return 'Attribution-NonCommercial-ShareAlike.';
    case 'cc-by-nc-nd':
      return 'Attribution-NonCommercial-NoDerivatives.';
    default:
      return 'License terms unknown.';
  }
};