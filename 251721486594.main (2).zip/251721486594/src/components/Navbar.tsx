import { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';
import { useTheme } from '@/hooks/useTheme';

export default function Navbar() {
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-sm sticky top-0 z-10 transition-colors duration-300">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <i className="fa-solid fa-palette text-2xl text-blue-600 dark:text-blue-400"></i>
          <span className="font-bold text-xl text-gray-800 dark:text-white">AI Art Portfolio</span>
        </Link>

        <div className="flex items-center space-x-6">
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
          >
            {theme === 'light' ? (
              <i className="fa-solid fa-moon text-gray-600"></i>
            ) : (
              <i className="fa-solid fa-sun text-yellow-400"></i>
            )}
          </button>

          {isAuthenticated ? (
            <>
              <Link 
                to="/upload" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors flex items-center"
              >
                <i className="fa-solid fa-upload mr-2"></i>
                <span>Upload</span>
              </Link>
              
              <div className="relative group">
                <button className="flex items-center space-x-2 focus:outline-none">
                  <img 
                    src={user.avatar || "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=user%20avatar%20default&sign=cf460a20a73def094c1c95d4c67653ab"} 
                    alt={user.name}
                    className="w-8 h-8 rounded-full object-cover border-2 border-gray-200 dark:border-gray-700"
                  />
                  <span className="hidden md:inline text-gray-700 dark:text-gray-200">{user.name}</span>
                  <i className="fa-solid fa-chevron-down text-xs text-gray-500"></i>
                </button>
                
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg py-2 z-20 hidden group-hover:block transition-all duration-200">
                  <button 
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    <i className="fa-solid fa-sign-out-alt mr-2"></i>Logout
                  </button>
                </div>
              </div>
            </>
          ) : (
            <Link 
              to="/login" 
              className="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg transition-colors dark:bg-gray-700 dark:hover:bg-gray-600"
            >
              <i className="fa-solid fa-user mr-2"></i>Login
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}