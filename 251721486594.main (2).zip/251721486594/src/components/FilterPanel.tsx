import { useState } from 'react';
import { motion } from 'framer-motion';
import { allArtStyles } from '@/mocks/artworks';

interface FilterPanelProps {
  activeFilters: string[];
  onFilterChange: (filters: string[]) => void;
}

export default function FilterPanel({ activeFilters, onFilterChange }: FilterPanelProps) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleFilter = (style: string) => {
    let newFilters;
    if (activeFilters.includes(style)) {
      newFilters = activeFilters.filter(f => f !== style);
    } else {
      newFilters = [...activeFilters, style];
    }
    onFilterChange(newFilters);
  };

  const clearFilters = () => {
    onFilterChange([]);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Art Styles</h3>
        
        <div className="flex items-center space-x-2">
          {activeFilters.length > 0 && (
            <button
              onClick={clearFilters}
              className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300"
            >
              Clear All
            </button>
          )}
          
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            aria-expanded={isOpen}
          >
            {isOpen ? (
              <i className="fa-solid fa-chevron-up"></i>
            ) : (
              <i className="fa-solid fa-chevron-down"></i>
            )}
          </button>
        </div>
      </div>
      
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ 
          height: isOpen || window.innerWidth >= 768 ? 'auto' : 0,
          opacity: isOpen || window.innerWidth >= 768 ? 1 : 0
        }}
        overflow="hidden"
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-wrap gap-2">
          {allArtStyles.map((style) => (
            <button
              key={style}
              onClick={() => toggleFilter(style)}
              className={`px-3 py-1 rounded-full text-sm transition-colors ${
                activeFilters.includes(style)
                  ? 'bg-blue-600 text-white hover:bg-blue-700'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {style}
            </button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}