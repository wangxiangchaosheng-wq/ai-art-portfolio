import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Artwork } from '@/types/artwork';
import CopyrightBadge from './CopyrightBadge';

interface ArtworkGridProps {
  artworks: Artwork[];
}

export default function ArtworkGrid({ artworks }: ArtworkGridProps) {
  if (artworks.length === 0) return null;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {artworks.map((artwork) => (
        <motion.div
          key={artwork.id}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.1 * artworks.indexOf(artwork) }}
          className="group"
        >
          <Link to={`/artwork/${artwork.id}`} className="block">
            <div className="relative overflow-hidden rounded-xl bg-white dark:bg-gray-800 shadow-md hover:shadow-xl transition-all duration-300 h-full flex flex-col">
              <div className="relative aspect-video overflow-hidden">
                <img 
                  src={artwork.imageUrl} 
                  alt={artwork.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute top-3 right-3">
                  <CopyrightBadge type={artwork.copyright} />
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                  <div className="p-4 w-full">
                    <div className="flex justify-between items-center">
                      <span className="text-white text-sm font-medium">
                        <i className="fa-regular fa-eye mr-1"></i> {artwork.views}
                      </span>
                      <span className="text-white text-sm font-medium">
                        <i className="fa-regular fa-heart mr-1"></i> {artwork.likes}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-4 flex-grow flex flex-col">
                <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-1 line-clamp-1">{artwork.title}</h3>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-3 line-clamp-2">{artwork.description}</p>
                <div className="mt-auto flex flex-wrap gap-2">
                  {artwork.tags.slice(0, 3).map((tag) => (
                    <span key={tag} className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-xs text-gray-700 dark:text-gray-300 rounded-full">
                      {tag}
                    </span>
                  ))}
                  {artwork.tags.length > 3 && (
                    <span className="px-2 py-1 bg-gray-100 dark:bg-gray-700 text-xs text-gray-700 dark:text-gray-300 rounded-full">
                      +{artwork.tags.length - 3}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}