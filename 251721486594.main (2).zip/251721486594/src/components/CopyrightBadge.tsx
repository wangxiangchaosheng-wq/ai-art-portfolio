import { Artwork } from '@/types/artwork';
import { getCopyrightLabel } from '@/types/artwork';

interface CopyrightBadgeProps {
  type: Artwork['copyright'];
}

export default function CopyrightBadge({ type }: CopyrightBadgeProps) {
  const getBadgeStyle = () => {
    switch (type) {
      case 'all-rights-reserved':
        return 'bg-red-500 hover:bg-red-600';
      case 'cc-by':
        return 'bg-blue-500 hover:bg-blue-600';
      case 'cc-by-sa':
        return 'bg-green-500 hover:bg-green-600';
      case 'cc-by-nd':
        return 'bg-purple-500 hover:bg-purple-600';
      case 'cc-by-nc':
        return 'bg-amber-500 hover:bg-amber-600';
      case 'cc-by-nc-sa':
        return 'bg-teal-500 hover:bg-teal-600';
      case 'cc-by-nc-nd':
        return 'bg-gray-500 hover:bg-gray-600';
      default:
        return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  return (
    <div className="relative inline-block">
      <button 
        className={`${getBadgeStyle()} text-white text-xs font-medium px-2 py-1 rounded-md flex items-center transition-colors`}
        aria-label={`Copyright: ${getCopyrightLabel(type)}`}
      >
        <i className="fa-regular fa-copyright mr-1"></i>
        <span>{getCopyrightLabel(type)}</span>
      </button>
    </div>
  );
}