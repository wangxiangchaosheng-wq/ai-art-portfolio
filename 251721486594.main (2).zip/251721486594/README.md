# AI Art Portfolio - 部署指南（小白版）

你好！这个指南会帮你把下载的代码变成一个真正可以在互联网上访问的网页。不需要懂编程，跟着步骤做就行！

## 准备工作

### 1. 安装必要软件

#### 安装Node.js（运行网站的基础工具）
1. 打开网站：https://nodejs.org/
2. 点击"Recommended For Most Users"按钮下载
3. 打开下载的文件，一直点击"下一步"完成安装（不需要修改任何设置）

#### 安装Git（代码管理工具）
1. 打开网站：https://git-scm.com/download/win
2. 下载后打开，出现安装界面时：
   - 点击"Next"
   - 勾选"Use Git from the Windows Command Prompt"（重要！）
   - 其他选项保持默认，继续点击"Next"直到安装完成

### 2. 注册必要账号（都是免费的）

1. **GitHub账号**（存放代码的地方）
   - 打开：https://github.com/
   - 点击"Sign up"注册，输入用户名、邮箱、密码
   - 验证邮箱后完成注册

2. **Vercel账号**（免费部署网站的平台）
   - 打开：https://vercel.com/signup
   - 点击"Continue with GitHub"
   - 授权GitHub登录后完成注册

## 开始部署

### 第一步：解压代码文件
1. 找到你下载的代码压缩包
2. 右键点击，选择"解压到当前文件夹"
3. 记住解压后的文件夹位置（比如"下载"文件夹）

### 第二步：上传代码到GitHub

1. **创建新仓库**
   - 登录GitHub后，点击右上角"+"号，选择"New repository"
   - 仓库名称填写：ai-art-portfolio（必须是这个名字！）
   - 勾选"Public"
   - 勾选"Add a README file"
   - 点击"Create repository"

2. **上传代码**
   - 打开你解压代码的文件夹
   - 在空白处按住Shift键，同时右键点击，选择"在此处打开命令窗口"
   - 在弹出的黑色窗口中，复制粘贴以下命令（一行一行来）：

```
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/你的GitHub用户名/ai-art-portfolio.git
git push -u origin main
```

   - 出现提示时，输入你的GitHub用户名和密码（密码输入时看不到，输完按回车就行）

### 第三步：部署网站到Vercel

1. 登录Vercel后，点击"New Project"
2. 找到并点击你刚刚创建的"ai-art-portfolio"仓库
3. 点击"Import"
4. 点击"Deploy"（不需要修改任何设置）
5. 等待1-2分钟，看到绿色的"Congratulations"就完成了！
6. 点击"Visit"按钮，就能看到你的网站了！

## 登录网站

网站部署成功后，你可以用以下信息登录：
- 用户名：demo
- 密码：demo

## 常见问题

### Q: 命令窗口里出现红色错误怎么办？
A: 把错误信息复制下来，在百度搜索一下，或者重新按照步骤再来一次。

### Q: 网站部署后看不到我的作品？
A: 新上传的作品只会保存在你的本地浏览器中，刷新页面就会消失。如果想永久保存作品，需要搭建后端，这部分比较复杂，建议先熟悉基本操作。

### Q: 可以修改网站内容吗？
A: 可以！修改代码后，重复第二步的"上传代码到GitHub"步骤，Vercel会自动更新你的网站。

如果还有其他问题，随时问我！